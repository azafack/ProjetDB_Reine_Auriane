USE restaurant_tchello;
 
-- ---------------------------------------------------------------------
-- 1. UNIQUE : pas de doublon
-- ---------------------------------------------------------------------
-- Un meme client ne peut pas etre enregistre deux fois
ALTER TABLE Client      ADD CONSTRAINT uq_client_identite UNIQUE (nom, prenom, telephone);
-- Deux plats, menus, ingredients ou fournisseurs ne portent pas le meme nom
ALTER TABLE Plat        ADD CONSTRAINT uq_plat_nom        UNIQUE (nom_plat);
ALTER TABLE Menu        ADD CONSTRAINT uq_menu_nom        UNIQUE (nom_menu);
ALTER TABLE Ingredient  ADD CONSTRAINT uq_ingredient_nom  UNIQUE (nom_ingredient);
ALTER TABLE Fournisseur ADD CONSTRAINT uq_fournisseur_nom UNIQUE (nom_fournisseur);
 
-- ---------------------------------------------------------------------
-- 2. DEFAULT : valeur par defaut quand rien n'est precise
-- ---------------------------------------------------------------------
-- Une nouvelle reservation est "confirmee", une nouvelle commande "en cours"
ALTER TABLE Reservation ALTER COLUMN statut          SET DEFAULT 'confirmee';
ALTER TABLE Commande    ALTER COLUMN statut_commande SET DEFAULT 'en cours';
 
-- ---------------------------------------------------------------------
-- 3. CHECK : liste de valeurs (IN), intervalles (BETWEEN), comparaisons
-- ---------------------------------------------------------------------
-- Statuts autorises (regles de gestion : reservations, commandes)
ALTER TABLE Reservation ADD CONSTRAINT chk_reservation_statut
    CHECK (statut IN ('confirmee', 'annulee', 'honoree'));
ALTER TABLE Commande ADD CONSTRAINT chk_commande_statut
    CHECK (statut_commande IN ('en cours', 'servie', 'payee'));
 
-- Categories de plats, fonctions des employes, modes de paiement, unites
ALTER TABLE Plat ADD CONSTRAINT chk_plat_categorie
    CHECK (categorie_plat IN ('antipasti', 'pizza', 'pates', 'viande', 'poisson', 'dessert'));
ALTER TABLE Employe ADD CONSTRAINT chk_employe_fonction
    CHECK (fonction IN ('serveur', 'chef de rang', 'cuisinier', 'responsable de salle'));
ALTER TABLE Paiement ADD CONSTRAINT chk_paiement_mode
    CHECK (mode IN ('carte', 'especes', 'ticket restaurant'));
ALTER TABLE Ingredient ADD CONSTRAINT chk_ingredient_unite
    CHECK (unite IN ('kg', 'litre', 'piece'));
 
-- Intervalles : taille des groupes, places par table (dictionnaire : 1 chiffre),
-- quantite commandee, numero de ligne
ALTER TABLE Reservation ADD CONSTRAINT chk_reservation_personnes
    CHECK (nb_personnes BETWEEN 1 AND 99);
ALTER TABLE Table_resto ADD CONSTRAINT chk_table_places
    CHECK (nb_place BETWEEN 1 AND 9);
ALTER TABLE Ligne_commande ADD CONSTRAINT chk_ligne_quantite
    CHECK (qnt_commandee BETWEEN 1 AND 99);
ALTER TABLE Ligne_commande ADD CONSTRAINT chk_ligne_numero
    CHECK (num_ligne >= 1);
 
-- Prix, montants et quantites strictement positifs
ALTER TABLE Plat           ADD CONSTRAINT chk_plat_prix        CHECK (prix_plat > 0);
ALTER TABLE Menu           ADD CONSTRAINT chk_menu_prix        CHECK (prix_menu > 0);
ALTER TABLE Ligne_commande ADD CONSTRAINT chk_ligne_prix       CHECK (prix_ligne > 0);
ALTER TABLE Paiement       ADD CONSTRAINT chk_paiement_montant CHECK (montant > 0);
ALTER TABLE utiliser       ADD CONSTRAINT chk_utiliser_qnt     CHECK (qnt_utilise > 0);
ALTER TABLE proposer       ADD CONSTRAINT chk_proposer_prix    CHECK (prix_achat > 0);
ALTER TABLE livrer         ADD CONSTRAINT chk_livrer_qnt       CHECK (qnt_livree > 0);
 
-- Dates plausibles (pas de date avant l'ouverture des donnees)
ALTER TABLE Reservation ADD CONSTRAINT chk_reservation_date
    CHECK (date_reservation >= '2020-01-01 00:00:00');
ALTER TABLE Commande ADD CONSTRAINT chk_commande_date
    CHECK (date_commande >= '2020-01-01 00:00:00');
ALTER TABLE Paiement ADD CONSTRAINT chk_paiement_date
    CHECK (date_paiement >= '2020-01-01');
ALTER TABLE Employe ADD CONSTRAINT chk_employe_embauche
    CHECK (date_embauche >= '2000-01-01');
 
-- ---------------------------------------------------------------------
-- 4. CHECK sur plusieurs colonnes
-- ---------------------------------------------------------------------
-- Un plat vegetarien ne peut pas etre de la viande ni du poisson
ALTER TABLE Plat ADD CONSTRAINT chk_plat_vegetarien
    CHECK (plat_vegetarien = 0 OR categorie_plat NOT IN ('viande', 'poisson'));
 
-- ---------------------------------------------------------------------
-- 5. CHECK sur un format de donnee (expression reguliere)
-- ---------------------------------------------------------------------
-- Telephone : exactement 10 chiffres
ALTER TABLE Client ADD CONSTRAINT chk_client_telephone
    CHECK (telephone REGEXP '^[0-9]{10}$');
-- Nom et prenom non vides (espaces seuls refuses)
ALTER TABLE Client ADD CONSTRAINT chk_client_nom_prenom
    CHECK (CHAR_LENGTH(TRIM(nom)) > 0 AND CHAR_LENGTH(TRIM(prenom)) > 0);
 
-- ---------------------------------------------------------------------
-- 6. Triggers : regles impossibles a ecrire avec un CHECK
-- ---------------------------------------------------------------------
DELIMITER $$
 
-- Un employe ne peut pas etre son propre superieur, et un responsable
-- de salle n'a pas de superieur direct
CREATE TRIGGER trg_employe_avant_insertion
BEFORE INSERT ON Employe
FOR EACH ROW
BEGIN
    IF NEW.id_superieur IS NOT NULL AND NEW.id_superieur = NEW.id_employe THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Un employe ne peut pas etre son propre superieur';
    END IF;
    IF NEW.fonction = 'responsable de salle' AND NEW.id_superieur IS NOT NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Un responsable de salle n''a pas de superieur direct';
    END IF;
END$$
 
CREATE TRIGGER trg_employe_avant_modification
BEFORE UPDATE ON Employe
FOR EACH ROW
BEGIN
    IF NEW.id_superieur IS NOT NULL AND NEW.id_superieur = NEW.id_employe THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Un employe ne peut pas etre son propre superieur';
    END IF;
    IF NEW.fonction = 'responsable de salle' AND NEW.id_superieur IS NOT NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Un responsable de salle n''a pas de superieur direct';
    END IF;
END$$
 
-- Une table ne peut pas etre reservee deux fois a la meme date et heure
-- (les reservations annulees ne comptent pas)
CREATE TRIGGER trg_reserver_pas_de_double_reservation
BEFORE INSERT ON reserver
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1
        FROM reserver rv
        JOIN Reservation autre    ON autre.id_reservation = rv.id_reservation
        JOIN Reservation courante ON courante.id_reservation = NEW.id_reservation
        WHERE rv.nom_salle = NEW.nom_salle
          AND rv.num_table = NEW.num_table
          AND autre.date_reservation = courante.date_reservation
          AND autre.statut <> 'annulee'
          AND courante.statut <> 'annulee'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cette table est deja reservee a cette date et heure';
    END IF;
END$$
 
