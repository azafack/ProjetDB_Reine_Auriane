DROP DATABASE IF EXISTS restaurant_tchello;
CREATE DATABASE restaurant_tchello CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE restaurant_tchello;

CREATE TABLE Client (
    id_client   INT AUTO_INCREMENT,
    nom         VARCHAR(40) NOT NULL,
    prenom      VARCHAR(30) NOT NULL,
    telephone   VARCHAR(10) NOT NULL,
    PRIMARY KEY (id_client)
);

CREATE TABLE Salle (
    nom_salle   VARCHAR(30) NOT NULL,
    PRIMARY KEY (nom_salle)
);

CREATE TABLE Table_resto (
    nom_salle   VARCHAR(30) NOT NULL,
    num_table   TINYINT UNSIGNED NOT NULL,
    nb_place    TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (nom_salle, num_table),
    CONSTRAINT fk_table_salle
        FOREIGN KEY (nom_salle) REFERENCES Salle (nom_salle)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Reservation (
    id_reservation    INT AUTO_INCREMENT,
    date_reservation  DATETIME NOT NULL,
    nb_personnes      TINYINT UNSIGNED NOT NULL,
    statut            VARCHAR(10) NOT NULL,
    id_client         INT NOT NULL,
    PRIMARY KEY (id_reservation),
    CONSTRAINT fk_reservation_client
        FOREIGN KEY (id_client) REFERENCES Client (id_client)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE reserver (
    id_reservation  INT NOT NULL,
    nom_salle       VARCHAR(30) NOT NULL,
    num_table       TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (id_reservation, nom_salle, num_table),
    CONSTRAINT fk_reserver_reservation
        FOREIGN KEY (id_reservation) REFERENCES Reservation (id_reservation)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reserver_table
        FOREIGN KEY (nom_salle, num_table) REFERENCES Table_resto (nom_salle, num_table)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Employe (
    id_employe     INT AUTO_INCREMENT,
    nom_employe    VARCHAR(40) NOT NULL,
    prenom         VARCHAR(30) NOT NULL,
    fonction       VARCHAR(25) NOT NULL,
    date_embauche  DATE NOT NULL,
    id_superieur   INT NULL,
    PRIMARY KEY (id_employe),
    CONSTRAINT fk_employe_superieur
        FOREIGN KEY (id_superieur) REFERENCES Employe (id_employe)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Commande (
    id_commande      INT AUTO_INCREMENT,
    date_commande    DATETIME NOT NULL,
    statut_commande  VARCHAR(10) NOT NULL,
    id_employe       INT NOT NULL,
    nom_salle        VARCHAR(30) NOT NULL,
    num_table        TINYINT UNSIGNED NOT NULL,
    id_reservation   INT NULL,
    PRIMARY KEY (id_commande),
    CONSTRAINT fk_commande_employe
        FOREIGN KEY (id_employe) REFERENCES Employe (id_employe)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_commande_table
        FOREIGN KEY (nom_salle, num_table) REFERENCES Table_resto (nom_salle, num_table)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_commande_reservation
        FOREIGN KEY (id_reservation) REFERENCES Reservation (id_reservation)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Plat (
    id_plat          INT AUTO_INCREMENT,
    nom_plat         VARCHAR(60) NOT NULL,
    prix_plat        DECIMAL(5,2) NOT NULL,
    categorie_plat   VARCHAR(15) NOT NULL,
    plat_vegetarien  BOOLEAN NOT NULL,
    PRIMARY KEY (id_plat)
);

CREATE TABLE Ligne_commande (
    id_commande    INT NOT NULL,
    num_ligne      TINYINT UNSIGNED NOT NULL,
    qnt_commandee  TINYINT UNSIGNED NOT NULL,
    prix_ligne     DECIMAL(5,2) NOT NULL,
    id_plat        INT NOT NULL,
    PRIMARY KEY (id_commande, num_ligne),
    CONSTRAINT fk_ligne_commande
        FOREIGN KEY (id_commande) REFERENCES Commande (id_commande)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ligne_plat
        FOREIGN KEY (id_plat) REFERENCES Plat (id_plat)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Paiement (
    id_paiement    INT AUTO_INCREMENT,
    montant        DECIMAL(6,2) NOT NULL,
    mode           VARCHAR(20) NOT NULL,
    date_paiement  DATE NOT NULL,
    id_commande    INT NOT NULL,
    PRIMARY KEY (id_paiement),
    CONSTRAINT fk_paiement_commande
        FOREIGN KEY (id_commande) REFERENCES Commande (id_commande)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Menu (
    id_menu    INT AUTO_INCREMENT,
    nom_menu   VARCHAR(50) NOT NULL,
    prix_menu  DECIMAL(5,2) NOT NULL,
    PRIMARY KEY (id_menu)
);

CREATE TABLE composer (
    id_menu  INT NOT NULL,
    id_plat  INT NOT NULL,
    PRIMARY KEY (id_menu, id_plat),
    CONSTRAINT fk_composer_menu
        FOREIGN KEY (id_menu) REFERENCES Menu (id_menu)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_composer_plat
        FOREIGN KEY (id_plat) REFERENCES Plat (id_plat)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Ingredient (
    id_ingredient   INT AUTO_INCREMENT,
    nom_ingredient  VARCHAR(40) NOT NULL,
    unite           VARCHAR(10) NOT NULL,
    PRIMARY KEY (id_ingredient)
);

CREATE TABLE utiliser (
    id_plat        INT NOT NULL,
    id_ingredient  INT NOT NULL,
    qnt_utilise    DECIMAL(6,2) NOT NULL,
    PRIMARY KEY (id_plat, id_ingredient),
    CONSTRAINT fk_utiliser_plat
        FOREIGN KEY (id_plat) REFERENCES Plat (id_plat)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_utiliser_ingredient
        FOREIGN KEY (id_ingredient) REFERENCES Ingredient (id_ingredient)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Fournisseur (
    id_fournisseur   INT AUTO_INCREMENT,
    nom_fournisseur  VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_fournisseur)
);

CREATE TABLE proposer (
    id_ingredient   INT NOT NULL,
    id_fournisseur  INT NOT NULL,
    prix_achat      DECIMAL(6,2) NOT NULL,
    PRIMARY KEY (id_ingredient, id_fournisseur),
    CONSTRAINT fk_proposer_ingredient
        FOREIGN KEY (id_ingredient) REFERENCES Ingredient (id_ingredient)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_proposer_fournisseur
        FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur (id_fournisseur)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Date_livraison (
    date_livraison  DATE NOT NULL,
    PRIMARY KEY (date_livraison)
);

-- Association ternaire Livrer (fournisseur, ingredient, date)
CREATE TABLE livrer (
    id_ingredient   INT NOT NULL,
    id_fournisseur  INT NOT NULL,
    date_livraison  DATE NOT NULL,
    qnt_livree      DECIMAL(7,2) NOT NULL,
    PRIMARY KEY (id_ingredient, id_fournisseur, date_livraison),
    CONSTRAINT fk_livrer_ingredient
        FOREIGN KEY (id_ingredient) REFERENCES Ingredient (id_ingredient)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_livrer_fournisseur
        FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur (id_fournisseur)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_livrer_date
        FOREIGN KEY (date_livraison) REFERENCES Date_livraison (date_livraison)
        ON DELETE CASCADE ON UPDATE CASCADE
);
